const Storage = {
  getPreference(key, fallback = null) {
    try { const raw = localStorage.getItem("northstar:" + key);
    return raw === null ? fallback : JSON.parse(raw); }
    catch { return fallback; }
  },
  
  setPreference(key, value) {
    try {
      localStorage.setItem("northstar:" + key, JSON.stringify(value));
    }
    catch (error) {
      console.warn("Could not save preference", error);
    }
  },

  getSession(key, fallback = null) {
    try {
      const raw = sessionStorage.getItem("northstar:" + key);
      return raw === null ? fallback : JSON.parse(raw);
    }
    catch {
      return fallback;
    }
  },

  setSession(key, value) {
    try {
      sessionStorage.setItem("northstar:" + key, JSON.stringify(value));
    }
    catch (error) {
      console.warn("Could not save session state", error);
    }
  },

  removeSession(key) {
    try {
      sessionStorage.removeItem("northstar:" + key);
    }
    catch (error) {
      console.warn("Could not clear session state", error);
    }
  }
};