# 🌌 Northstar Workspace

## Offline-First Client & Project Management Dashboard

Northstar Workspace is a browser-based management application for organising **clients, projects, tasks, contacts, and payment records** in one workspace. It is built with **HTML5, CSS3, and Vanilla JavaScript**, using browser storage to keep application records and preferences on the user's device.

> **Project scope:** This is a frontend-only, local-first application. It does not use a backend, remote database, authentication system, cloud synchronisation, or real payment processing.

---

## ✨ Features

### 🗂️ Five Connected Management Modules

- **Clients** — Store client and company details.
- **Projects** — Track project status, budget, due date, notes, and an optional client relationship.
- **Tasks** — Track task status, priority, due date, notes, and an optional project relationship.
- **Contacts** — Store contact details and optionally link contacts to clients.
- **Payments** — Track payment/invoice references, amount, status, method, due date, notes, and an optional project relationship.

### 🛠️ Record Management

- Create, view, edit, and duplicate records.
- Soft-delete records to the Trash/Recycle Bin.
- Restore trashed records or permanently delete them.
- Select multiple records for supported bulk actions.
- Generate record IDs and maintain creation/update timestamps.
- Record workspace activity for recent changes.

### 🔎 Find and Organise Records

- Debounced search.
- Filter records by status, task priority, and related records where applicable.
- Sort and paginate records.
- Configure page size.
- Save supported view preferences.

### 🧾 Data Import and Export

- Export records to CSV.
- Import CSV data with validation and skipped-row feedback.
- Export JSON backups and import supported JSON backups.
- Validate supported fields and relationships during import.
- Use existing record IDs in CSV relationship fields such as `clientId` and `projectId`.

> **Recommendation:** Export a JSON backup before importing or restoring data.

### 🎨 Workspace Experience

- Light and dark themes with a saved preference.
- Icon-only Sun/Moon theme toggle.
- Theme styling for the workspace, navigation, and sidebar.
- Responsive desktop, tablet, and mobile layouts.
- Responsive sidebar dismissal through outside clicks, navigation selection, and the `Escape` key.
- Inline form validation and field-level feedback.
- Confirmation dialogs for destructive actions.
- Toast notifications for operations.
- Empty and loading states, including a skeleton-style loading screen.
- Keyboard-focus styling and reduced-motion CSS support.

### 📡 Offline App-Shell Support

- A Service Worker caches the local application shell and assets.
- After a successful initial load and Service Worker installation, the cached app shell can be opened offline.
- Application records remain in the browser's IndexedDB database.

Offline availability depends on the browser, the initial successful cache, and serving the application from **localhost or HTTPS**. Opening the HTML file directly with `file://` is not the recommended way to test Service Worker functionality.

---

## 🧰 Technology Stack

| Technology | Purpose |
|---|---|
| HTML5 | Application structure and form controls |
| CSS3 | Layout, responsive styling, themes, and UI states |
| Vanilla JavaScript (ES6+) | Application logic, DOM rendering, validation, and interactions |
| IndexedDB | Persistent records and activity data |
| LocalStorage | Persistent user preferences |
| SessionStorage | Temporary view state and recoverable unsaved form drafts |
| Service Worker / Cache API | Offline app-shell caching |
| Web App Manifest | Application metadata and install-related display settings |

No React, Vue, Angular, jQuery, Bootstrap, backend, or external database is used.

---

## 📁 Project Structure

```text
Northstar-Workspace/
├── index.html
├── manifest.webmanifest
├── service-worker.js
├── icon.svg
├── README.md
├── CHANGELOG.md
├── css/
│   └── style.css
└── js/
    ├── app.js
    ├── database.js
    └── storage.js
```

### 🧩 Main JavaScript Files

- **`js/app.js`** — Application controller, module configuration, UI rendering, form validation, relationships, record actions, import/export, and activity events.
- **`js/database.js`** — IndexedDB connection, schema upgrades, indexes, and record transaction helpers.
- **`js/storage.js`** — Guarded LocalStorage preference and SessionStorage state helpers.
- **`service-worker.js`** — Versioned application-shell cache, offline navigation fallback, and asset caching.
- **`manifest.webmanifest`** — App name, short name, description, launch path, display mode, theme/background colours, and icon metadata.

---

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `Ctrl` / `Cmd` + `K` | Focus the search field |
| `Ctrl` / `Cmd` + `N` | Open a new record form for the current module |
| `Ctrl` / `Cmd` + `Shift` + `E` | Export the current supported module view to CSV |
| `Escape` | Close the responsive sidebar when it is open |

---

## 📥 Import Formats

### CSV Import

Import a CSV file while the relevant module is open. The first row should contain the field keys used by that module.

Example for Clients:

```csv
name,email,phone,company,status
Acme Studio,hello@example.com,+91 9876543210,Acme,Active
```

For relationships, use existing record IDs in `clientId` or `projectId`, as applicable. Unsupported columns may be ignored; invalid rows can be skipped and reported by the importer.

### JSON Backup and Restore

Use the application's JSON backup export to create a restore file in the supported format. The importer merges records by ID: a matching ID is replaced, while records with other IDs are retained. Import validation checks supported record shapes and field values before writing staged records.

Keep a separate backup before importing. As with any browser-only application, imported data and existing data are stored locally in the current browser profile.

---

## 🗄️ Data Model and Relationships

| Store | Data stored |
|---|---|
| `clients` | Client and organisation information |
| `projects` | Project information, optional `clientId`, budget, status, and due date |
| `tasks` | Task information, optional `projectId`, status, priority, and due date |
| `contacts` | Contact information, optional `clientId`, role, email, and phone |
| `payments` | Payment/invoice tracking information, optional `projectId`, amount, status, and method |
| `activity` | Timestamped workspace activity and related record metadata |

The IndexedDB schema is versioned and includes indexes for common record fields and relationships. The application uses local browser storage; records are not shared automatically between browsers or devices.

---

## ⚠️ Scope and Limitations

- **Local-only data:** Records are stored in the current browser profile/device. They are not automatically synchronised elsewhere.
- **No authentication or multi-user access:** The application has no login system, server-side permissions, or collaborative features.
- **Payment tracking only:** Payment records are informational; the app does not process transactions.
- **Browser storage is not a backup service:** Clearing site data or browser storage can remove records. Export JSON backups regularly.
- **Offline caching has prerequisites:** The app must first load successfully, and the Service Worker must cache the required assets on localhost or HTTPS.
- **CSV relationships use IDs:** Relationship columns should use existing record IDs, not display names.

---

## 📝 Changelog

### Date Validation and Reliability Pass

- Made calendar-date validation timezone-independent by parsing HTML date values at UTC midnight.
- Updated the Service Worker cache version so changed local assets can be fetched after the cache refreshes.
- The project includes versioned IndexedDB schema/index setup, storage helpers, CSV export formula-risk mitigation, and a bounded activity history.

---

## 🎓 Project Objective

Northstar Workspace demonstrates frontend engineering concepts including DOM manipulation, modular JavaScript, asynchronous browser APIs, IndexedDB transactions, data relationships, client-side validation, import/export workflows, responsive UI design, and offline app-shell caching—all without a frontend framework or backend.

**Built with HTML, CSS, and JavaScript. 🌌**

---

## ✍️ Author

**Aradhya Dhanger**